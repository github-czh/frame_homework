package com.czh;

import com.czh.po.Customer;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.junit.Test;
import s1613023085.po.SqlHelper;


public class MyBatisTest {

//    @Test
//    public void findCustomerByIdTest() throws Exception{
//        String resource="mybatis-config.xml";
//        InputStream inputStream= Resources.getResourceAsStream(resource);
//        SqlSessionFactory sqlSessionFactory=new SqlSessionFactoryBuilder().build(inputStream);
//        SqlSession sqlSession=sqlSessionFactory.openSession();
//        Customer customer=sqlSession.selectOne("CustomerMapper.findCustomerById",1);
//        System.out.println(customer.toString());
//        sqlSession.close();
//
//    }
//    @Test
//    public void findCustomerByNameTest()throws Exception{
//        String resource="mybatis-config.xml";
//        InputStream inputStream= Resources.getResourceAsStream(resource);
//        SqlSessionFactory sqlSessionFactory=new SqlSessionFactoryBuilder().build(inputStream);
//        SqlSession sqlSession=sqlSessionFactory.openSession();
//        List<Customer> customers=sqlSession.selectList("findCustomerByName","j");
//        for(Customer customer:customers)
//            System.out.println(customer);
//
//        sqlSession.close();
//    }
    @Test
    public void findCustomerByName(){
        SqlSession sqlSession=SqlHelper.getSqlSession();
        Customer customer=new Customer();
        customer.setUsername("j");
        List<Customer> customers=sqlSession.selectList("findCustomerByName",customer);
        for(Customer customer1:customers){
            System.out.println(customer1);
        }
        sqlSession.close();
    }
    @Test
    public void addCustomerTest()throws Exception{
        String resource="mybatis-config.xml";
        InputStream inputStream= Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory=new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession=sqlSessionFactory.openSession();
        Customer customer=new Customer();
        customer.setUsername("czh");
        customer.setJobs("student");
        customer.setPhone("13270620725");
        int rows=sqlSession.insert("addCustomer", "customer");
        if(rows>0){
            System.out.println("您成功插入了"+rows+"行数据");
        }else{
            System.out.println("执行插入操作失败");
        }
        sqlSession.commit();
        sqlSession.close();
    }

    @Test
    public void updateCustomer()throws  Exception{
        String resource="mybatis-config.xml";
        InputStream inputStream= Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory=new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession=sqlSessionFactory.openSession();
        Customer customer=new Customer();
        customer.setId(4);
        customer.setUsername("czh");
        customer.setJobs("doctor");
        customer.setPhone("13552866685");
        int rows=sqlSession.update("CustomerMapper.updateCustomer", customer);
        if(rows>0){
            System.out.println("您成功修改了"+rows+"一行数据!");
        }else{
            System.out.println("修改操作执行失败!!!");
        }
        sqlSession.commit();
        sqlSession.close();
    }
    @Test
    public void deleteCustomer()throws Exception{
        String resource="mybatis-config.xml";
        InputStream inputStream=Resources.getResourceAsStream(resource);
        SqlSessionFactory sqlSessionFactory=new SqlSessionFactoryBuilder().build(inputStream);
        SqlSession sqlSession=sqlSessionFactory.openSession();
        int rows=sqlSession.delete("deleteCustomer", 5);
        if(rows>0){
            System.out.println("您成功删除了"+rows+"一条数据!");
        }else{
            System.out.println("数据删除失败!!!");
        }
        sqlSession.commit();
        sqlSession.close();
    }
    @Test
    public void findCustomerByNameAndJobsTest(){
        SqlSession sqlSession=SqlHelper.getSqlSession();
        Customer customer=new Customer();
        customer.setUsername("czh");
        customer.setJobs("doctor");
        List<Customer> customers=sqlSession.selectList("findCustomerByNameAndJobs",customer);
        for (Customer customer1:customers){
            System.out.println(customer1);
        }
        sqlSession.close();
    }
    @Test
    public void findCustomerByNameOrJobsTest(){
        SqlSession sqlSession=SqlHelper.getSqlSession();
        Customer customer=new Customer();
        customer.setUsername("czh");
        customer.setJobs("doctor");
        List<Customer> customers=sqlSession.selectList("findCustomerByNameOrJobs",customer);
        for(Customer customer1:customers){
            System.out.println(customer1);
        }
        sqlSession.close();
    }
    @Test
    public void updateCustomerTest(){
        SqlSession sqlSession=SqlHelper.getSqlSession();
        Customer customer=new Customer();
        customer.setId(3);
        customer.setPhone("13552866685");
        int rows=sqlSession.update("updateCustomer", customer);
        if(rows>0){
            System.out.println("您成功地修改了"+rows+"行数据");
        }else{
            System.out.println("执行修改操作失败!!!");
        }
        sqlSession.commit();
        sqlSession.close();
    }
    @Test
    public void findCustomerByIdsTest(){
        SqlSession sqlSession=SqlHelper.getSqlSession();
        List<Integer> ids=new ArrayList<Integer>();
        ids.add(1);
        ids.add(2);
        List<Customer> customers=sqlSession.selectList("findCustomerByIds",ids);
        for(Customer customer:customers){
            System.out.println(customer);
        }
        sqlSession.close();
    }
}