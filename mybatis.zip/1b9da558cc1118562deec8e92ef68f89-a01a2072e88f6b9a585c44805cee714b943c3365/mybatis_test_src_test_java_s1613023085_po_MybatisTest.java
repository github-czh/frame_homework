package s1613023085.po;

import com.czh.po.Customer;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;
import sun.java2d.loops.CustomComponent;

import java.util.ArrayList;
import java.util.List;

public class MybatisTest {
    @Test
    public void insertStudent()throws Exception{
        SqlSession sqlSession=SqlHelper.getSqlSession();
        Student student=new Student();
        student.setLoginname("admin");
        student.setPassword("11");
        student.setUsername("李孙");
        int rows=sqlSession.insert("addStudent",student);
        if(rows>0)
            System.out.println("插入ok");
        else
            System.out.println("插入error");
        sqlSession.commit();
        sqlSession.close();
    }
    @Test
    public void findStudentById()throws Exception{
        SqlSession sqlSession=SqlHelper.getSqlSession();
        Student student=sqlSession.selectOne("findStudentById", 3);
        System.out.println(student.toString());
        sqlSession.close();
    }
    @Test
    public void findStudentByName()throws Exception{
        SqlSession sqlSession=SqlHelper.getSqlSession();
        List<Student> students=sqlSession.selectList("findStudentByName","李");
        for(Student student:students){
            System.out.println(student);
        }
        sqlSession.close();
    }
//    @Test
//    public void updateStudent()throws Exception{
//        SqlSession sqlSession=SqlHelper.getSqlSession();
//
//        Student student=new Student();
//        student.setId(3);
//        student.setLoginname("user");
//        student.setPassword("123");
//        student.setUsername("华仔");
//        int rows=sqlSession.update("updateStudent",student);
//        if(rows>0) {
//            System.out.println("更新ok");
//        }else
//            System.out.println("更新error");
//        sqlSession.commit();
//        sqlSession.close();
//    }
    @Test
    public void deleteStudent()throws Exception{
        SqlSession sqlSession=SqlHelper.getSqlSession();
        int rows=sqlSession.delete("deleteStudent",5);
        if(rows>0)
            System.out.println("删除ok");
        else
            System.out.println("删除error");
        sqlSession.commit();
        sqlSession.close();
    }

    @Test
    public void findByLoginNameAndUserName(){
        SqlSession sqlSession=SqlHelper.getSqlSession();
        Student student=new Student();
        student.setLoginname("user");
        student.setUsername("华仔");
        List<Student> students=sqlSession.selectList("findByLoginNameAndUserName",student);
        for (Student student1:students){
            System.out.println(student1);
        }
        sqlSession.close();
    }
    @Test
    public void findByLoginNameOrUserName(){
        SqlSession sqlSession=SqlHelper.getSqlSession();
        Student student=new Student();
        student.setLoginname("user");
        student.setUsername("华仔");
        List<Student> students=sqlSession.selectList("findByLoginNameOrUserName",student);
        for (Student student1:students){
            System.out.println(student1);
        }
        sqlSession.close();
    }
    @Test
    public void findByWhere(){
        SqlSession sqlSession=SqlHelper.getSqlSession();
        Student student=new Student();
        //student.setLoginname("user");
        student.setUsername("华仔");
        List<Student> students=sqlSession.selectList("findByLoginNameOrUserName",student);
        for (Student student1:students){
            System.out.println(student1);
        }
        sqlSession.close();
    }
    @Test
    public void updateStudent(){
        SqlSession sqlSession=SqlHelper.getSqlSession();
        Student student=new Student();
        student.setId(1);
        student.setUsername("czh");
        student.setPassword("123456");
        int rows=sqlSession.update("updateStudent",student);

        if(rows>0){
            System.out.println("您成功地修改了"+rows+"行数据");
        }else{
            System.out.println();
        }
        sqlSession.commit();
        sqlSession.close();
    }
    @Test
    public void findStudentByIds(){
        SqlSession sqlSession=SqlHelper.getSqlSession();
        List<Integer> ids=new ArrayList<Integer>();
        ids.add(1);
        ids.add(3);
        ids.add(5);
        List<Student> students=sqlSession.selectList("findStudentByIds",ids);
        for(Student student:students){
            System.out.println(student);
        }
        sqlSession.close();

    }


}